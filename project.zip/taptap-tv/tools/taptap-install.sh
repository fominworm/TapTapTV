#!/usr/bin/env bash
# TapTap TV: put an APK on an Android TV from a Linux computer over Wi-Fi.
# Usage: ./taptap-install.sh <tv-ip> <file.apk> [port]
# On the TV: Settings > About > press Build number 7 times > Developer options > USB debugging.
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 <tv-ip> <file.apk> [port]" >&2
  exit 1
fi
IP="$1"; APK="$2"; PORT="${3:-5555}"

command -v adb >/dev/null 2>&1 || {
  echo "adb not found. Install it: sudo apt install adb   (or your distribution's android-tools)" >&2
  exit 1
}
[ -f "$APK" ] || { echo "File not found: $APK" >&2; exit 1; }

echo "Connecting to $IP:$PORT ... (accept the prompt on the TV: Always allow, OK)"
adb connect "$IP:$PORT"
adb -s "$IP:$PORT" wait-for-device
echo "Installing $APK ..."
adb -s "$IP:$PORT" install -r "$APK"
echo "Done. Look for the app on the TV in All apps."
