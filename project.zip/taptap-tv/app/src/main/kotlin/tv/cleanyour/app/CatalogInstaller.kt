package tv.cleanyour.app

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import tv.cleanyour.core.flows.AccessResult
import tv.cleanyour.core.model.RawShell
import tv.cleanyour.core.model.Sha256
import tv.cleanyour.core.model.ShellLine
import tv.cleanyour.core.model.TvId
import tv.cleanyour.core.session.InstallOutcome
import tv.cleanyour.core.session.TvSession

// Sends an app from the catalog to the TV: opens its Play page there, or downloads its APK on the
// phone (HTTPS only, from the maker's own release page) and installs it over the debugging connection.
// A change the person asked for by name, one app at a time; it never touches the cleaning plan.
class CatalogInstaller(private val graph: AppGraph, private val context: Context) {

    sealed interface Step {
        data object Connecting : Step
        data class Downloading(val done: Long, val total: Long) : Step
        data object Installing : Step
    }

    enum class Failure { NO_CONNECTION, NOT_FOUND, DOWNLOAD, INSTALL, PLAY }

    sealed interface Outcome {
        data object Done : Outcome
        data class Failed(val why: Failure, val detail: String = "") : Outcome
    }

    // A live session when there is one; otherwise the usual reconnect, for at most 25 s (the debugging
    // step of Manage is the place to wait longer, and it is there that the person is sent).
    private suspend fun session(tvId: TvId): TvSession? {
        graph.access.live(tvId)?.let { return it }
        val r = withTimeoutOrNull(25_000) { graph.access.session(tvId) }
        if (r == null) { graph.access.cancelWaiting(); return null }
        return (r as? AccessResult.Ok)?.session
    }

    @OptIn(RawShell::class)
    suspend fun openInPlay(tvId: TvId, app: CatalogApp): Outcome {
        val s = session(tvId) ?: return Outcome.Failed(Failure.NO_CONNECTION)
        val pkg = app.playPkg
        val uri = if (pkg != null && PKG_RE.matches(pkg)) "market://details?id=$pkg"
        else "market://search?q=" + URLEncoder.encode(app.name, "UTF-8") + "&c=apps"
        val r = runCatching { s.exec(ShellLine("am start -a android.intent.action.VIEW -d '$uri'")) }.getOrNull()
            ?: return Outcome.Failed(Failure.PLAY)
        val bad = r.exit != 0 || r.stdout.contains("Error", ignoreCase = true) || r.stderr.contains("Error", ignoreCase = true) ||
            r.stdout.contains("unable to resolve", ignoreCase = true)
        return if (bad) Outcome.Failed(Failure.PLAY, (r.stdout + r.stderr).take(200)) else Outcome.Done
    }

    suspend fun installApk(tvId: TvId, app: CatalogApp, onStep: (Step) -> Unit): Outcome {
        val source = app.apk ?: return Outcome.Failed(Failure.NOT_FOUND)
        if (graph.store.hosts.isEmpty()) return Outcome.Failed(Failure.NOT_FOUND)   // the Play build downloads nothing
        onStep(Step.Connecting)
        if (session(tvId) == null) return Outcome.Failed(Failure.NO_CONNECTION)
        val file = File(context.cacheDir, "catalog-${app.id}.apk")
        try {
            val url = withContext(Dispatchers.IO) { resolve(source) } ?: return Outcome.Failed(Failure.NOT_FOUND)
            val (hex, size) = withContext(Dispatchers.IO) { download(url, file) { d, t -> onStep(Step.Downloading(d, t)) } }
                ?: return Outcome.Failed(Failure.DOWNLOAD)
            onStep(Step.Installing)
            return pushInstall(tvId, file, hex, size)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return Outcome.Failed(Failure.DOWNLOAD, e.javaClass.simpleName)
        } finally {
            withContext(NonCancellable) { runCatching { file.delete() } }
        }
    }


    // An APK the person picked on the phone (their own file): hashed here, then sent the same way.
    suspend fun installLocal(tvId: TvId, file: File, onStep: (Step) -> Unit): Outcome {
        if (graph.store.hosts.isEmpty()) return Outcome.Failed(Failure.NOT_FOUND)
        onStep(Step.Connecting)
        if (session(tvId) == null) return Outcome.Failed(Failure.NO_CONNECTION)
        return try {
            val (hex, size) = withContext(Dispatchers.IO) { hashOf(file) }
            onStep(Step.Installing)
            pushInstall(tvId, file, hex, size)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Outcome.Failed(Failure.DOWNLOAD, e.javaClass.simpleName)
        } finally {
            withContext(NonCancellable) { runCatching { file.delete() } }
        }
    }

    // The blob store holds the file only while it is sent, then it is deleted.
    private suspend fun pushInstall(tvId: TvId, file: File, hex: String, size: Long): Outcome {
        val digest = Sha256(hex)
        try {
            val blob = FileInputStream(file).use { graph.blobs.put(digest, it, size) }
            // The session may have closed during a long download: ask for it again.
            val s = session(tvId) ?: return Outcome.Failed(Failure.NO_CONNECTION)
            return when (val o = s.installStream(blob, size)) {
                is InstallOutcome.Installed -> Outcome.Done
                is InstallOutcome.Failed -> Outcome.Failed(Failure.INSTALL, o.code)
            }
        } finally {
            withContext(NonCancellable) { runCatching { graph.blobs.delete(digest) } }
        }
    }

    // A photo or any file from the phone to the TV's folder /sdcard/cleanyourtv (a file manager or
    // gallery app on the TV opens it from there).
    @OptIn(RawShell::class)
    suspend fun sendFile(tvId: TvId, file: File, remoteName: String): Outcome {
        val s = session(tvId) ?: return Outcome.Failed(Failure.NO_CONNECTION)
        return try {
            val (hex, size) = withContext(Dispatchers.IO) { hashOf(file) }
            val digest = Sha256(hex)
            try {
                val blob = FileInputStream(file).use { graph.blobs.put(digest, it, size) }
                runCatching { s.exec(ShellLine("mkdir -p /sdcard/cleanyourtv")) }
                val dest = tv.cleanyour.core.model.RemotePath(tv.cleanyour.core.model.RemoteDir.RESTORE, listOf(remoteName))
                s.push(blob, dest)
                Outcome.Done
            } finally {
                withContext(NonCancellable) { runCatching { graph.blobs.delete(digest) } }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Outcome.Failed(Failure.DOWNLOAD, e.javaClass.simpleName)
        } finally {
            withContext(NonCancellable) { runCatching { file.delete() } }
        }
    }

    // One remote-control key (the mini remote). A fixed list of key codes, never text from the person.
    @OptIn(RawShell::class)
    suspend fun key(tvId: TvId, code: Int): Boolean {
        val s = session(tvId) ?: return false
        val r = runCatching { s.exec(ShellLine("input keyevent $code")) }.getOrNull() ?: return false
        return r.exit == 0
    }

    private fun hashOf(file: File): Pair<String, Long> {
        val md = MessageDigest.getInstance("SHA-256")
        var n = 0L
        file.inputStream().use { i ->
            val buf = ByteArray(64 * 1024)
            while (true) { val r = i.read(buf); if (r < 0) break; md.update(buf, 0, r); n += r }
        }
        return md.digest().joinToString("") { "%02x".format(it) } to n
    }

    private fun resolve(source: ApkSource): String? = when (source) {
        is ApkSource.Direct -> source.url.takeIf { it.startsWith("https://") }
        is ApkSource.GithubRelease -> latestAsset(source)
    }

    private fun latestAsset(s: ApkSource.GithubRelease): String? {
        val body = httpGetText("https://api.github.com/repos/${s.repo}/releases/latest") ?: return null
        val assets = JSONObject(body).optJSONArray("assets") ?: return null
        val re = Regex(s.nameRegex)
        val found = (0 until assets.length()).map { assets.getJSONObject(it) }
            .filter { re.containsMatchIn(it.optString("name")) && it.optString("name").endsWith(".apk", ignoreCase = true) }
        if (found.isEmpty()) return null
        val pick = s.prefer.firstNotNullOfOrNull { p -> found.firstOrNull { it.optString("name").contains(p, ignoreCase = true) } } ?: found.first()
        return pick.optString("browser_download_url").takeIf { it.startsWith("https://") }
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "TapTapTV")
        c.setRequestProperty("Accept", "application/vnd.github+json, application/octet-stream, */*")
        return c
    }

    private fun httpGetText(url: String): String? = runCatching {
        val c = open(url)
        try { if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null } finally { c.disconnect() }
    }.getOrNull()

    // Returns the SHA-256 (hex) and the size of the file written, or null when the download failed.
    private fun download(url: String, out: File, progress: (Long, Long) -> Unit): Pair<String, Long>? = runCatching {
        val c = open(url)
        try {
            if (c.responseCode != 200) return@runCatching null
            val total = c.contentLengthLong
            if (total > MAX_BYTES) return@runCatching null
            val md = MessageDigest.getInstance("SHA-256")
            var done = 0L
            var lastReport = 0L
            c.inputStream.use { input ->
                out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n); md.update(buf, 0, n); done += n
                        if (done > MAX_BYTES) return@runCatching null
                        if (done - lastReport >= 256 * 1024) { lastReport = done; progress(done, total) }
                    }
                }
            }
            if (done == 0L || (total > 0 && done != total)) return@runCatching null
            progress(done, total)
            md.digest().joinToString("") { "%02x".format(it) } to done
        } finally { c.disconnect() }
    }.getOrNull()

    private companion object {
        val PKG_RE = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
        const val MAX_BYTES = 400L * 1024 * 1024
    }
}
