package tv.cleanyour.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import tv.cleanyour.ui.design.component.CytBottomSheet
import tv.cleanyour.ui.design.component.CytIconButton
import tv.cleanyour.ui.design.component.CytTopBar
import tv.cleanyour.ui.design.component.Gap
import tv.cleanyour.ui.design.component.Lead
import tv.cleanyour.ui.design.component.ListDivider
import tv.cleanyour.ui.design.component.ListGroup
import tv.cleanyour.ui.design.component.ListRow
import tv.cleanyour.ui.design.component.ScreenScaffold
import tv.cleanyour.ui.design.component.ScreenTitle
import tv.cleanyour.ui.design.component.SheetHeader
import tv.cleanyour.ui.design.component.StepCard
import tv.cleanyour.ui.design.icon.CytIcons
import tv.cleanyour.ui.design.theme.CytTheme
import tv.cleanyour.ui.design.theme.Glow

// TapTap TV's own screens: the loading screen, the main menu with its seven buttons, Settings
// (language, instructions, support, developer) and the instructions page. They only call routes;
// every action on the TV stays in the screens that already own it.

private val NeonCyan = Color(0xFF22D3FF)
private val NeonViolet = Color(0xFF8B5CF6)
private val NeonPink = Color(0xFFE040FB)
private val RimBrush = Brush.horizontalGradient(listOf(NeonCyan, NeonViolet, NeonPink))
private val FillBrush = Brush.horizontalGradient(listOf(Color(0x40103CFF), Color(0x33101030), Color(0x40A020F0)))

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Color(0xFF02030F))) {
        Image(
            painterResource(R.drawable.taptap_splash),
            contentDescription = stringResource(R.string.app_name),
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
    }
}

enum class MenuItem { START, MY_TV, HOME_SCREEN, SWITCHED_OFF, LEFTOVERS, RESTORE, GUIDE }

private class MenuEntry(val item: MenuItem, val icon: ImageVector, val title: Int, val subtitle: Int)

private val menuEntries = listOf(
    MenuEntry(MenuItem.START, CytIcons.Wifi, R.string.menu_start, R.string.menu_start_sub),
    MenuEntry(MenuItem.MY_TV, CytIcons.Tv, R.string.menu_my_tv, R.string.menu_my_tv_sub),
    MenuEntry(MenuItem.HOME_SCREEN, CytIcons.Home, R.string.menu_home_screen, R.string.menu_home_screen_sub),
    MenuEntry(MenuItem.SWITCHED_OFF, CytIcons.Shield, R.string.menu_switched_off, R.string.menu_switched_off_sub),
    MenuEntry(MenuItem.LEFTOVERS, CytIcons.Refresh, R.string.menu_leftovers, R.string.menu_leftovers_sub),
    MenuEntry(MenuItem.RESTORE, CytIcons.Undo, R.string.menu_restore, R.string.menu_restore_sub),
    MenuEntry(MenuItem.GUIDE, CytIcons.Help, R.string.menu_guide, R.string.menu_guide_sub),
)

@Composable
fun MenuScreen(tvName: String?, onItem: (MenuItem) -> Unit, onSettings: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xFF02030F))) {
        Image(
            painterResource(R.drawable.taptap_menu_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            val header = 132.dp
            val spacing = 12.dp
            // Seven buttons fill the screen on a tall phone; on a short one, or at a large font, they scroll.
            val fit = (maxHeight - header - spacing * 7) / 7
            val buttonHeight: Dp = fit.coerceIn(68.dp, 92.dp)
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().height(header).padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(R.drawable.taptap_logo),
                        contentDescription = stringResource(R.string.app_name),
                        modifier = Modifier.height(104.dp),
                        contentScale = ContentScale.Fit,
                    )
                    Box(Modifier.weight(1f))
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(FillBrush)
                            .border(1.5.dp, RimBrush, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        CytIconButton(CytIcons.Settings, stringResource(R.string.menu_settings_cd), onSettings, tint = Color.White)
                    }
                }
                TvLine(if (tvName != null) fmt(R.string.menu_tv_line, "name" to tvName) else stringResource(R.string.menu_no_tv))
                Column(Modifier.padding(top = 8.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(spacing)) {
                    menuEntries.forEach { e ->
                        MenuButton(stringResource(e.title), stringResource(e.subtitle), e.icon, buttonHeight) { onItem(e.item) }
                    }
                }
            }
        }
    }
}

// App-level strings with arguments follow the project rule: ICU MessageFormat, named arguments.
@Composable
private fun fmt(id: Int, vararg args: Pair<String, Any>): String =
    ResourceFlowCopy.format(LocalContext.current, id, mapOf(*args))

@Composable
private fun TvLine(text: String) {
    androidx.compose.material3.Text(
        text, Modifier.padding(start = 4.dp, bottom = 4.dp),
        style = CytTheme.type.bodyMedium, color = CytTheme.colors.textSecondary,
    )
}

@Composable
private fun MenuButton(title: String, subtitle: String, icon: ImageVector, height: Dp, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier.fillMaxWidth().height(height).clip(shape).background(FillBrush, shape)
            .border(1.5.dp, RimBrush, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0x5522D3FF), Color(0x55E040FB)))),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.Center) {
            androidx.compose.material3.Text(title, style = CytTheme.type.titleMedium, color = CytTheme.colors.textPrimary, maxLines = 2)
            androidx.compose.material3.Text(subtitle, style = CytTheme.type.bodySmall, color = CytTheme.colors.textSecondary, maxLines = 2)
        }
        Icon(CytIcons.ChevronForward, contentDescription = null, tint = Color(0xFFB9C4FF), modifier = Modifier.size(22.dp))
    }
}

// The language names are written in their own language, whatever language the app shows.
@Composable
private fun languageName(tag: String): String = when (tag) {
    AppLanguage.RU -> "Русский"
    AppLanguage.EN -> "English"
    else -> stringResource(R.string.language_system)
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun TapTapSettingsScreen(
    languageTag: String,
    version: String,
    onBack: () -> Unit,
    onPickLanguage: (String) -> Unit,
    onGuide: () -> Unit,
    onSupport: () -> Unit,
    onDeveloper: () -> Unit,
    onAdvanced: () -> Unit,
) {
    var picking by remember { mutableStateOf(false) }
    ScreenScaffold(
        Glow.Brand,
        topBar = { CytTopBar(onBack = onBack) },
        overlay = {
            if (picking) CytBottomSheet(onDismissRequest = { picking = false }) {
                SheetHeader(stringResource(R.string.settings_language_title), subtitle = stringResource(R.string.settings_language_hint))
                Gap(8.dp)
                val selectedMark: @Composable () -> Unit = { Icon(CytIcons.Check, contentDescription = null, tint = NeonCyan) }
                AppLanguage.options.forEach { tag ->
                    ListRow(
                        languageName(tag),
                        trailing = if (tag == languageTag) selectedMark else null,
                        onClick = { picking = false; if (tag != languageTag) onPickLanguage(tag) },
                    )
                    ListDivider()
                }
                Gap(16.dp)
            }
        },
    ) {
        ScreenTitle(stringResource(R.string.settings_title), Modifier.padding(top = 20.dp))
        ListGroup(Modifier.padding(top = 16.dp)) {
            ListRow(stringResource(R.string.settings_language), value = languageName(languageTag), onClick = { picking = true })
            ListDivider()
            ListRow(stringResource(R.string.settings_guide), subtitle = stringResource(R.string.settings_guide_sub), onClick = onGuide)
        }
        ListGroup(Modifier.padding(top = 12.dp)) {
            ListRow(stringResource(R.string.settings_support), subtitle = stringResource(R.string.settings_support_sub), onClick = onSupport)
            ListDivider()
            ListRow(stringResource(R.string.settings_developer), subtitle = "@" + TapTapLinks.DEVELOPER_HANDLE, onClick = onDeveloper)
        }
        ListGroup(Modifier.padding(top = 12.dp)) {
            ListRow(stringResource(R.string.settings_advanced), subtitle = stringResource(R.string.settings_advanced_sub), onClick = onAdvanced)
        }
        Lead(fmt(R.string.settings_about, "version" to version), Modifier.padding(top = 20.dp, bottom = 24.dp))
    }
}

private class GuideStep(val title: Int, val body: Int)

private val guideSteps = listOf(
    GuideStep(R.string.guide_1_title, R.string.guide_1_body),
    GuideStep(R.string.guide_2_title, R.string.guide_2_body),
    GuideStep(R.string.guide_3_title, R.string.guide_3_body),
    GuideStep(R.string.guide_4_title, R.string.guide_4_body),
    GuideStep(R.string.guide_5_title, R.string.guide_5_body),
    GuideStep(R.string.guide_6_title, R.string.guide_6_body),
    GuideStep(R.string.guide_7_title, R.string.guide_7_body),
    GuideStep(R.string.guide_8_title, R.string.guide_8_body),
)

@Composable
fun GuideScreen(onBack: () -> Unit, onSupport: () -> Unit) {
    ScreenScaffold(Glow.Brand, topBar = { CytTopBar(onBack = onBack) }) {
        ScreenTitle(stringResource(R.string.guide_title), Modifier.padding(top = 20.dp))
        Lead(stringResource(R.string.guide_lead), Modifier.padding(top = 8.dp))
        guideSteps.forEachIndexed { i, s ->
            StepCard(
                title = stringResource(s.title),
                body = stringResource(s.body),
                modifier = Modifier.padding(top = 12.dp),
                overline = fmt(R.string.guide_step, "current" to (i + 1), "total" to guideSteps.size),
            )
        }
        ListGroup(Modifier.padding(top = 16.dp, bottom = 24.dp)) {
            ListRow(stringResource(R.string.guide_need_help), subtitle = stringResource(R.string.guide_need_help_sub), onClick = onSupport)
        }
    }
}
