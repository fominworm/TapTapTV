package tv.cleanyour.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import tv.cleanyour.ui.design.component.Banner
import tv.cleanyour.ui.design.component.BannerTone
import tv.cleanyour.ui.design.component.CytBottomSheet
import tv.cleanyour.ui.design.component.CytIconButton
import tv.cleanyour.ui.design.component.CytTopBar
import tv.cleanyour.ui.design.component.Gap
import tv.cleanyour.ui.design.component.Lead
import tv.cleanyour.ui.design.component.ListDivider
import tv.cleanyour.ui.design.component.ListGroup
import tv.cleanyour.ui.design.component.ListRow
import tv.cleanyour.ui.design.component.Overline
import tv.cleanyour.ui.design.component.PagerDots
import tv.cleanyour.ui.design.component.PrimaryButton
import tv.cleanyour.ui.design.component.ScreenScaffold
import tv.cleanyour.ui.design.component.ScreenTitle
import tv.cleanyour.ui.design.component.SecondaryButton
import tv.cleanyour.ui.design.component.SheetHeader
import tv.cleanyour.ui.design.component.StepCard
import tv.cleanyour.ui.design.component.TertiaryButton
import tv.cleanyour.ui.design.icon.CytIcons
import tv.cleanyour.ui.design.theme.CytTheme
import tv.cleanyour.ui.design.theme.Glow

// TapTap TV's own screens: the loading screen, the main menu, Settings, the swipeable instructions
// and the app catalog. They only call routes and the installer; every action on the TV that changes
// the cleaning stays in the screens that already own it.

private val NeonCyan = Color(0xFF22D3FF)
private val NeonViolet = Color(0xFF8B5CF6)
private val NeonPink = Color(0xFFE040FB)
private val RimBrush = Brush.horizontalGradient(listOf(NeonCyan, NeonViolet, NeonPink))
private val FillBrush = Brush.horizontalGradient(listOf(Color(0x40103CFF), Color(0x33101030), Color(0x40A020F0)))
private val ContentMaxWidth = 560.dp   // tablets and foldables: the column keeps a phone's width, centred

// App-level strings with arguments follow the project rule: ICU MessageFormat, named arguments.
@Composable
private fun fmt(id: Int, vararg args: Pair<String, Any>): String =
    ResourceFlowCopy.format(LocalContext.current, id, mapOf(*args))

// The one brand mark: the app icon and the name set in the app's own type, so every screen shows the
// same lettering instead of a picture of it.
@Composable
private fun BrandMark(iconSize: Dp, textSize: Int, modifier: Modifier = Modifier, centered: Boolean = false) {
    val inner: @Composable () -> Unit = {
        Image(painterResource(R.drawable.taptap_icon), contentDescription = null, modifier = Modifier.size(iconSize))
        Text(
            stringResource(R.string.app_name),
            style = CytTheme.type.display.copy(brush = RimBrush, fontSize = textSize.sp, fontWeight = FontWeight.Bold),
            maxLines = 1,
        )
    }
    if (centered) Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) { inner() }
    else Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) { inner() }
}

@Composable
fun SplashScreen() {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(700), label = "splash")
    Box(Modifier.fillMaxSize().background(Color(0xFF02030F))) {
        Image(painterResource(R.drawable.taptap_menu_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        BrandMark(iconSize = 220.dp, textSize = 44, modifier = Modifier.align(Alignment.Center).alpha(a), centered = true)
    }
}

enum class MenuItem { START, APPS, MY_TV, HOME_SCREEN, SWITCHED_OFF, LEFTOVERS, RESTORE, GUIDE }

private class MenuEntry(val item: MenuItem, val icon: ImageVector, val title: Int, val subtitle: Int)

private val menuEntries = listOf(
    MenuEntry(MenuItem.START, CytIcons.Wifi, R.string.menu_start, R.string.menu_start_sub),
    MenuEntry(MenuItem.APPS, CytIcons.Tv, R.string.menu_apps, R.string.menu_apps_sub),
    MenuEntry(MenuItem.MY_TV, CytIcons.Tv, R.string.menu_my_tv, R.string.menu_my_tv_sub),
    MenuEntry(MenuItem.HOME_SCREEN, CytIcons.Home, R.string.menu_home_screen, R.string.menu_home_screen_sub),
    MenuEntry(MenuItem.SWITCHED_OFF, CytIcons.Shield, R.string.menu_switched_off, R.string.menu_switched_off_sub),
    MenuEntry(MenuItem.LEFTOVERS, CytIcons.Refresh, R.string.menu_leftovers, R.string.menu_leftovers_sub),
    MenuEntry(MenuItem.RESTORE, CytIcons.Undo, R.string.menu_restore, R.string.menu_restore_sub),
    MenuEntry(MenuItem.GUIDE, CytIcons.Help, R.string.menu_guide, R.string.menu_guide_sub),
)

@Composable
fun MenuScreen(tvName: String?, onItem: (MenuItem) -> Unit, onSettings: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xFF02030F))) {
        Image(painterResource(R.drawable.taptap_menu_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing), contentAlignment = Alignment.TopCenter) {
            val header = 92.dp
            val spacing = 10.dp
            val count = menuEntries.size
            // Every button has the same height: as much as the screen allows between 64 and 76 dp,
            // so a short phone, a long one and a large font all show one family of buttons.
            val buttonHeight: Dp = ((maxHeight - header - 48.dp - spacing * (count - 1)) / count).coerceIn(64.dp, 76.dp)
            Column(Modifier.widthIn(max = ContentMaxWidth).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().height(header).padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    BrandMark(iconSize = 64.dp, textSize = 30)
                    Box(Modifier.weight(1f))
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(FillBrush).border(1.5.dp, RimBrush, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center,
                    ) { CytIconButton(CytIcons.Settings, stringResource(R.string.menu_settings_cd), onSettings, tint = Color.White) }
                }
                Text(
                    if (tvName != null) fmt(R.string.menu_tv_line, "name" to tvName) else stringResource(R.string.menu_no_tv),
                    Modifier.padding(start = 4.dp, top = 4.dp, bottom = 12.dp),
                    style = CytTheme.type.bodyMedium, color = CytTheme.colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Column(Modifier.padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(spacing)) {
                    menuEntries.forEach { e -> MenuButton(stringResource(e.title), stringResource(e.subtitle), e.icon, buttonHeight) { onItem(e.item) } }
                }
            }
        }
    }
}

@Composable
private fun MenuButton(title: String, subtitle: String, icon: ImageVector, height: Dp, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().height(height).clip(shape).background(FillBrush, shape).border(1.5.dp, RimBrush, shape)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0x5522D3FF), Color(0x55E040FB)))),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.Center) {
            Text(title, style = CytTheme.type.titleMedium, color = CytTheme.colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = CytTheme.type.bodySmall, color = CytTheme.colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(CytIcons.ChevronForward, contentDescription = null, tint = Color(0xFFB9C4FF), modifier = Modifier.size(22.dp))
    }
}

// The language names are written in their own language, whatever language the app shows.
@Composable
private fun languageName(tag: String): String = when (tag) {
    AppLanguage.RU -> "Русский"
    AppLanguage.EN -> "English"
    else -> stringResource(R.string.language_system)
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun TapTapSettingsScreen(
    languageTag: String,
    version: String,
    onBack: () -> Unit,
    onPickLanguage: (String) -> Unit,
    onGuide: () -> Unit,
    onSupport: () -> Unit,
    onDeveloper: () -> Unit,
    onAdvanced: () -> Unit,
) {
    var picking by remember { mutableStateOf(false) }
    ScreenScaffold(
        Glow.Brand,
        topBar = { CytTopBar(onBack = onBack) },
        overlay = {
            if (picking) CytBottomSheet(onDismissRequest = { picking = false }) {
                SheetHeader(stringResource(R.string.settings_language_title), subtitle = stringResource(R.string.settings_language_hint))
                Gap(8.dp)
                val selectedMark: @Composable () -> Unit = { Icon(CytIcons.Check, contentDescription = null, tint = NeonCyan) }
                AppLanguage.options.forEach { tag ->
                    ListRow(
                        languageName(tag),
                        trailing = if (tag == languageTag) selectedMark else null,
                        onClick = { picking = false; if (tag != languageTag) onPickLanguage(tag) },
                    )
                    ListDivider()
                }
                Gap(16.dp)
            }
        },
    ) {
        Column(Modifier.widthIn(max = ContentMaxWidth).align(Alignment.CenterHorizontally)) {
            ScreenTitle(stringResource(R.string.settings_title), Modifier.padding(top = 20.dp))
            ListGroup(Modifier.padding(top = 16.dp)) {
                ListRow(stringResource(R.string.settings_language), value = languageName(languageTag), onClick = { picking = true })
                ListDivider()
                ListRow(stringResource(R.string.settings_guide), subtitle = stringResource(R.string.settings_guide_sub), onClick = onGuide)
            }
            ListGroup(Modifier.padding(top = 12.dp)) {
                ListRow(stringResource(R.string.settings_support), subtitle = stringResource(R.string.settings_support_sub), onClick = onSupport)
                ListDivider()
                ListRow(stringResource(R.string.settings_developer), subtitle = "@" + TapTapLinks.DEVELOPER_HANDLE, onClick = onDeveloper)
            }
            ListGroup(Modifier.padding(top = 12.dp)) {
                ListRow(stringResource(R.string.settings_advanced), subtitle = stringResource(R.string.settings_advanced_sub), onClick = onAdvanced)
            }
            Lead(fmt(R.string.settings_about, "version" to version), Modifier.padding(top = 20.dp, bottom = 24.dp))
        }
    }
}

// Instructions: one page per step; swiping moves to the next page, which repeats the same card on
// the same background with the next step's number and text.
private class GuideStep(val title: Int, val body: Int)

private val guideSteps = listOf(
    GuideStep(R.string.guide_1_title, R.string.guide_1_body),
    GuideStep(R.string.guide_2_title, R.string.guide_2_body),
    GuideStep(R.string.guide_3_title, R.string.guide_3_body),
    GuideStep(R.string.guide_4_title, R.string.guide_4_body),
    GuideStep(R.string.guide_5_title, R.string.guide_5_body),
    GuideStep(R.string.guide_6_title, R.string.guide_6_body),
    GuideStep(R.string.guide_7_title, R.string.guide_7_body),
    GuideStep(R.string.guide_8_title, R.string.guide_8_body),
    GuideStep(R.string.guide_9_title, R.string.guide_9_body),
)

@Composable
fun GuideScreen(onBack: () -> Unit, onSupport: () -> Unit) {
    val total = guideSteps.size
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    val page = pager.currentPage
    ScreenScaffold(
        Glow.Brand,
        topBar = { CytTopBar(onBack = onBack) },
        scrollable = false,
        bottomBar = {
            Column(Modifier.widthIn(max = ContentMaxWidth).align(Alignment.CenterHorizontally)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PagerDots(total, page, description = fmt(R.string.guide_step, "current" to (page + 1), "total" to total))
                    Spacer(Modifier.weight(1f))
                    if (page > 0) TertiaryButton(stringResource(R.string.guide_prev), { scope.launch { pager.animateScrollToPage(page - 1) } })
                }
                Gap(12.dp)
                if (page < total - 1) PrimaryButton(stringResource(R.string.guide_next), { scope.launch { pager.animateScrollToPage(page + 1) } }, Modifier.fillMaxWidth())
                else PrimaryButton(stringResource(R.string.guide_done), onBack, Modifier.fillMaxWidth())
            }
        },
    ) {
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { i ->
            val s = guideSteps[i]
            Column(
                Modifier.widthIn(max = ContentMaxWidth).fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (i == 0) {
                    ScreenTitle(stringResource(R.string.guide_title), Modifier.padding(top = 4.dp))
                    Lead(stringResource(R.string.guide_lead), Modifier.padding(top = 8.dp))
                }
                StepCard(
                    title = stringResource(s.title),
                    body = stringResource(s.body),
                    modifier = Modifier.padding(top = 16.dp),
                    overline = fmt(R.string.guide_step, "current" to (i + 1), "total" to total),
                    illustration = { StepBadge(i + 1) },
                )
                if (i == total - 1) {
                    ListGroup(Modifier.padding(top = 16.dp)) {
                        ListRow(stringResource(R.string.guide_need_help), subtitle = stringResource(R.string.guide_need_help_sub), onClick = onSupport)
                    }
                }
                Text(
                    stringResource(R.string.guide_swipe_hint), Modifier.padding(top = 16.dp), textAlign = TextAlign.Center,
                    style = CytTheme.type.bodySmall, color = CytTheme.colors.textTertiary,
                )
            }
        }
    }
}

@Composable
private fun StepBadge(n: Int) {
    Box(
        Modifier.size(84.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0x5522D3FF), Color(0x55E040FB)))).border(1.5.dp, RimBrush, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(n.toString(), style = CytTheme.type.display.copy(brush = RimBrush, fontSize = 40.sp, fontWeight = FontWeight.Bold)) }
}

// ---- App catalog -------------------------------------------------------------------------------

sealed interface AppItemState {
    data object Idle : AppItemState
    data class Busy(val label: Int, val percent: Int? = null) : AppItemState
    data class Done(val message: Int) : AppItemState
    data class Failed(val message: Int) : AppItemState
}

private fun categoryTitle(c: AppCategory): Int = when (c) {
    AppCategory.TV_CHANNELS -> R.string.apps_cat_tv
    AppCategory.VIDEO -> R.string.apps_cat_video
    AppCategory.VPN -> R.string.apps_cat_vpn
    AppCategory.TOOLS -> R.string.apps_cat_tools
}

@Composable
fun AppsScreen(
    tvName: String?,
    states: Map<String, AppItemState>,
    apkEnabled: Boolean,
    onBack: () -> Unit,
    onInstall: (CatalogApp) -> Unit,
    onPlay: (CatalogApp) -> Unit,
) {
    val russian = LocalConfiguration.current.locales[0].language == "ru"
    var confirm by remember { mutableStateOf<CatalogApp?>(null) }
    ScreenScaffold(Glow.Brand, topBar = { CytTopBar(onBack = onBack) }) {
        Column(Modifier.widthIn(max = ContentMaxWidth).align(Alignment.CenterHorizontally)) {
            ScreenTitle(stringResource(R.string.apps_title), Modifier.padding(top = 20.dp))
            Lead(if (tvName != null) fmt(R.string.apps_lead, "name" to tvName) else stringResource(R.string.apps_lead_no_tv), Modifier.padding(top = 8.dp))
            Banner(stringResource(R.string.apps_note_debug), BannerTone.INFO, Modifier.padding(top = 16.dp))
            AppCategory.entries.forEach { cat ->
                Overline(stringResource(categoryTitle(cat)), Modifier.padding(start = 4.dp, top = 24.dp, bottom = 8.dp))
                AppCatalog.byCategory(cat).forEach { app ->
                    AppCard(app, app.description(russian), states[app.id] ?: AppItemState.Idle, tvName != null, apkEnabled, onInstall = { confirm = app }, onPlay = { onPlay(app) })
                    Gap(10.dp)
                }
            }
            Lead(stringResource(R.string.apps_footer), Modifier.padding(top = 16.dp, bottom = 24.dp))
        }
        confirm?.let { app ->
            AlertDialog(
                onDismissRequest = { confirm = null },
                title = { Text(fmt(R.string.apps_confirm_title, "name" to app.name)) },
                text = { Text(fmt(R.string.apps_confirm_body, "name" to app.name, "tv" to (tvName ?: ""))) },
                confirmButton = { TextButton(onClick = { confirm = null; onInstall(app) }) { Text(stringResource(R.string.apps_install)) } },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text(stringResource(R.string.apps_cancel)) } },
            )
        }
    }
}

@Composable
private fun AppCard(app: CatalogApp, description: String, state: AppItemState, hasTv: Boolean, apkEnabled: Boolean, onInstall: () -> Unit, onPlay: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val busy = state is AppItemState.Busy
    Column(Modifier.fillMaxWidth().clip(shape).background(FillBrush, shape).border(1.5.dp, RimBrush, shape).padding(16.dp)) {
        Text(app.name, style = CytTheme.type.titleMedium, color = CytTheme.colors.textPrimary)
        Text(description, Modifier.padding(top = 4.dp), style = CytTheme.type.bodySmall, color = CytTheme.colors.textSecondary)
        val status: String? = when (state) {
            is AppItemState.Busy -> if (state.percent != null) fmt(state.label, "percent" to state.percent) else stringResource(state.label)
            is AppItemState.Done -> stringResource(state.message)
            is AppItemState.Failed -> stringResource(state.message)
            AppItemState.Idle -> null
        }
        if (status != null) {
            Text(
                status, Modifier.padding(top = 8.dp), style = CytTheme.type.bodySmall,
                color = if (state is AppItemState.Failed) Color(0xFFFF8A80) else NeonCyan,
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (app.apk != null && apkEnabled) {
                PrimaryButton(stringResource(R.string.apps_install), onInstall, Modifier.weight(1f), enabled = hasTv && !busy, loading = busy)
                if (app.playPkg != null) SecondaryButton(stringResource(R.string.apps_play_short), onPlay, Modifier.weight(1f), enabled = hasTv && !busy)
            } else if (app.playPkg != null || app.apk == null) {
                PrimaryButton(stringResource(R.string.apps_play), onPlay, Modifier.weight(1f), enabled = hasTv && !busy, loading = busy)
            }
        }
    }
}
