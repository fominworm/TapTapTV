package tv.cleanyour.app

// TapTap TV: the list of apps the person can put on the TV from the phone. Only legal software:
// free-to-watch TV and film services, players, VPN clients that bring their own servers, small tools.
// Each app is installed one of two ways: "Install" downloads the APK from its maker's own release page
// to the phone and sends it to the TV over the same debugging connection, or the Play page of the app
// opens on the TV (the person presses Install there with the remote).
enum class AppCategory { TV_CHANNELS, VIDEO, VPN, TOOLS }

// Where an APK comes from. GitHub releases are read at the moment of the tap, so the newest build is
// found without the app knowing a version; the first asset whose name matches `prefer` in order wins.
sealed interface ApkSource {
    data class GithubRelease(val repo: String, val nameRegex: String, val prefer: List<String> = emptyList()) : ApkSource
    data class Direct(val url: String) : ApkSource
}

class CatalogApp(
    val id: String,
    val name: String,
    val category: AppCategory,
    val ru: String,
    val en: String,
    val playPkg: String? = null,      // null: the Play search for the name opens on the TV instead of the exact page
    val apk: ApkSource? = null,
    val playOnly: Boolean = false,    // no APK the maker publishes openly: Play only
) {
    fun description(russian: Boolean): String = if (russian) ru else en
}

object AppCatalog {
    val apps: List<CatalogApp> = listOf(
        // Free TV channels and live TV
        CatalogApp("limehd", "Lime HD TV", AppCategory.TV_CHANNELS,
            "Сотни бесплатных телеканалов в эфире, с программой передач.",
            "Hundreds of free live TV channels with a programme guide."),
        CatalogApp("peers", "Peers.TV", AppCategory.TV_CHANNELS,
            "Бесплатное онлайн-ТВ: федеральные и региональные каналы, архив передач.",
            "Free online TV: national and regional channels, programme archive."),
        CatalogApp("pluto", "Pluto TV", AppCategory.TV_CHANNELS,
            "Сотни бесплатных тематических каналов и кино по запросу.",
            "Hundreds of free themed channels and films on demand.", playPkg = "tv.pluto.android"),
        CatalogApp("tubi", "Tubi", AppCategory.TV_CHANNELS,
            "Бесплатное кино и сериалы с рекламой, прямые эфиры.",
            "Free ad-supported films, series and live channels.", playPkg = "com.tubitv"),
        CatalogApp("tivimate", "TiviMate IPTV Player", AppCategory.TV_CHANNELS,
            "Удобный плеер для ваших плейлистов IPTV от своего провайдера.",
            "A comfortable player for your own provider's IPTV playlists.", playPkg = "ar.tvplayer.tv"),
        CatalogApp("wink", "Wink", AppCategory.TV_CHANNELS,
            "Телеканалы и кино от Ростелекома; часть каналов бесплатно.",
            "TV channels and films from Rostelecom; some channels are free."),
        // Video services
        CatalogApp("youtube", "YouTube", AppCategory.VIDEO,
            "Официальное приложение YouTube для ТВ.",
            "The official YouTube app for TV.", playPkg = "com.google.android.youtube.tv"),
        CatalogApp("smarttube", "SmartTube", AppCategory.VIDEO,
            "Открытый клиент YouTube для ТВ: без рекламы, удобное управление пультом.",
            "An open-source YouTube client for TV: no ads, remote-friendly.",
            apk = ApkSource.GithubRelease("yuliskov/SmartTube", "(?i)smarttube.*\\.apk", listOf("armeabi-v7a", "arm64-v8a", "universal"))),
        CatalogApp("rutube", "Rutube", AppCategory.VIDEO,
            "Российский видеохостинг: шоу, фильмы и прямые эфиры.",
            "A video platform with shows, films and live streams."),
        CatalogApp("vkvideo", "VK Видео", AppCategory.VIDEO,
            "Видео, трансляции и телеканалы от VK.",
            "Video, live streams and TV channels from VK."),
        CatalogApp("kinopoisk", "Кинопоиск", AppCategory.VIDEO,
            "Кино и сериалы по подписке, есть бесплатные подборки.",
            "Films and series by subscription, some free collections."),
        CatalogApp("okko", "Okko", AppCategory.VIDEO,
            "Онлайн-кинотеатр: фильмы, сериалы, спорт.",
            "An online cinema: films, series, sport."),
        CatalogApp("twitch", "Twitch", AppCategory.VIDEO,
            "Прямые трансляции игр и шоу.",
            "Live streams of games and shows.", playPkg = "tv.twitch.android.app"),
        CatalogApp("plex", "Plex", AppCategory.VIDEO,
            "Ваша медиатека с телефона или компьютера плюс бесплатные каналы.",
            "Your own media library plus free channels.", playPkg = "com.plexapp.android"),
        CatalogApp("kodi", "Kodi", AppCategory.VIDEO,
            "Открытый медиацентр: ваши файлы, музыка, дополнения.",
            "An open-source media centre: your files, music, add-ons.", playPkg = "org.xbmc.kodi"),
        CatalogApp("vlc", "VLC", AppCategory.VIDEO,
            "Плеер, который открывает почти любой файл и поток.",
            "The player that opens almost any file or stream.", playPkg = "org.videolan.vlc"),
        // VPN clients: they bring no servers, the person adds their own subscription or server
        CatalogApp("happ", "Happ", AppCategory.VPN,
            "Прокси-клиент на ядре Xray: ваша подписка или свой сервер. Серверов не даёт.",
            "A proxy client on the Xray core: your own subscription or server. It provides none.",
            playPkg = "com.happproxy", apk = ApkSource.Direct("https://github.com/Happ-proxy/happ-android/releases/latest/download/Happ.apk")),
        CatalogApp("incy", "Incy", AppCategory.VPN,
            "VPN-клиент: подписка в один клик, разные протоколы. Серверов не даёт.",
            "A VPN client: one-tap subscriptions, many protocols. It provides no servers.",
            playPkg = "llc.itdev.incy", playOnly = true),
        // Tools
        CatalogApp("downloader", "Downloader", AppCategory.TOOLS,
            "Скачивает файлы и APK по ссылке прямо на ТВ.",
            "Downloads files and APKs from a link right on the TV.", playPkg = "com.esaba.downloader"),
        CatalogApp("sendfiles", "Send Files to TV", AppCategory.TOOLS,
            "Передача файлов с телефона на ТВ по Wi-Fi.",
            "Send files from the phone to the TV over Wi-Fi.", playPkg = "com.yablio.sendfilestotv"),
        CatalogApp("xplore", "X-plore", AppCategory.TOOLS,
            "Файловый менеджер для ТВ с поддержкой облаков и сети.",
            "A file manager for TV with cloud and network support.", playPkg = "com.lonelycatgames.Xplore"),
    )

    fun byCategory(c: AppCategory): List<CatalogApp> = apps.filter { it.category == c }
}
