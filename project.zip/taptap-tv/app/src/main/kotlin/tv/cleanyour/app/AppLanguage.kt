package tv.cleanyour.app

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

// The language the person picked in Settings. "system" follows the phone. The choice is kept in a
// private preferences file and applied to every Activity in attachBaseContext, so the whole app
// (Compose strings, ICU plurals, dates) reads the same locale. Changing it recreates the Activity.
object AppLanguage {
    const val SYSTEM = "system"
    const val RU = "ru"
    const val EN = "en"

    // Order of the picker: the phone's own, then the languages the app ships.
    val options: List<String> = listOf(SYSTEM, RU, EN)

    private const val PREFS = "taptap_prefs"
    private const val KEY = "language"

    fun saved(context: Context): String {
        val v = runCatching { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, SYSTEM) }.getOrNull()
        return if (v != null && v in options) v else SYSTEM
    }

    fun save(context: Context, tag: String) {
        if (tag !in options) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, tag).apply()
    }

    // The Application's own resources follow the choice too: the notification text and the sentences
    // the flows write (ResourceFlowCopy) are made from the application context, not from the Activity.
    @Suppress("DEPRECATION")
    fun refreshApplication(app: Context) {
        val tag = saved(app)
        val locale = if (tag == SYSTEM) android.content.res.Resources.getSystem().configuration.locales[0] else Locale.forLanguageTag(tag)
        val res = app.applicationContext.resources
        val conf = Configuration(res.configuration)
        conf.setLocale(locale)
        res.updateConfiguration(conf, res.displayMetrics)
        Locale.setDefault(locale)
    }

    // A context whose resources use the saved language; the base itself when it follows the phone.
    fun wrap(base: Context): Context {
        val tag = saved(base)
        if (tag == SYSTEM) return base
        val locale = Locale.forLanguageTag(tag)
        Locale.setDefault(locale)
        val conf = Configuration(base.resources.configuration)
        conf.setLocale(locale)
        conf.setLayoutDirection(locale)
        return base.createConfigurationContext(conf)
    }
}
