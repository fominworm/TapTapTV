package tv.cleanyour.app

// The only outside addresses the app sends a person to. Support and the developer are Telegram.
object TapTapLinks {
    const val SUPPORT = "https://t.me/TapTapSoft"
    const val DEVELOPER = "https://t.me/flomaster6"
    const val DEVELOPER_HANDLE = "flomaster6"

    // Every link that pointed at the upstream project's GitHub (issue forms, release page, TV list)
    // opens the support chat instead; the report text is already on the clipboard when it does.
    fun redirect(url: String): String {
        val u = url.trim()
        return if (
            u.startsWith("https://github.com/udhaykumarbala/") ||
            u.startsWith("https://api.github.com/repos/udhaykumarbala/") ||
            u.startsWith("https://udhaykumarbala.github.io/")
        ) SUPPORT else u
    }
}
